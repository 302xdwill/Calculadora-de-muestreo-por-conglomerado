from flask import Flask, render_template, request
import numpy as np
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

def calcular_media_varianza(datos):
    # Calcular medias y varianzas de los conglomerados
    medias = []
    varianzas = []
    for conglomerado in datos:
        medias.append(np.mean(conglomerado))
        varianzas.append(np.var(conglomerado, ddof=1))
    return medias, varianzas

# Función para calcular la media y la varianza
def calcular_resultados(medias_cong, varianza_cong, M, N):
    # Estimación de la media
    media_estimacion = np.mean(medias_cong)
    
    # Calcular la varianza
    varianza = (np.mean(varianza_cong) / M) * (1 - (M / N))  # Fórmula de varianza para conglomerados bietápicos
    
    return media_estimacion, varianza

# Ruta para ingresar los datos
@app.route('/ingresar_datos', methods=['GET', 'POST'])
def ingresar_datos():
    if request.method == 'POST':
        # Obtener el número de conglomerados seleccionados
        M = int(request.form['num_conglomerados'])
        
        # Obtener los datos de cada conglomerado
        conglomerados = []
        for i in range(M):
            datos_conglomerado = list(map(float, request.form[f'conglomerado_{i+1}'].split(',')))
            conglomerados.append(datos_conglomerado)
        
        # Calcular las medias y las varianzas de los conglomerados
        medias_cong, varianza_cong = calcular_media_varianza(conglomerados)
        
        # Obtener el número total de conglomerados (N)
        N = int(request.form['total_cong'])
        
        # Calcular la media y la varianza del estimador
        media_estimacion, varianza = calcular_resultados(medias_cong, varianza_cong, M, N)
        
        # Generar gráfico de varianza
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, varianza], label="Varianza Estimada", color='r')
        ax.set_title("Gráfico de la Varianza")
        ax.set_xlabel("Número de Conglomerados")
        ax.set_ylabel("Varianza")
        
        # Convertir gráfico a imagen en base64 para renderizarlo en la página
        img = io.BytesIO()
        fig.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()

        return render_template('result.html', media_estimacion=media_estimacion, varianza=varianza, plot_url=plot_url)

    return render_template('ingresar_datos.html')

# Ruta para la página principal
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
